Data for On the Utility of GPU Accelerated High-Order Methods for Unsteady Flow Simulations: A Comparison with Industry Standard Tools. B. C. Vermeire, F. D. Witherden, P. E. Vincent. Journal of Computational Physics

figs/ contains data for respective figures
misc/ contains other data used in producing the paper
configs/ contains configuration descriptions for the STAR-CCM+ simulations
patch/ contains code patches
